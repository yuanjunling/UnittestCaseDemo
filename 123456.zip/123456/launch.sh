java -jar device-proxy-0.0.1-SNAPSHOT.jar
